#!/bin/sh

SRC="./fy22_deliverable/rules"
DST="osa_rules"

if [ $# -eq 0 ]
	then
		echo "No arguments supplied. Using default \"./fy22_deliverable/rules\" and \"osa_rules\""
elif [ $# -ne 2 ]
	then
		echo "Invalid number of arguments"
else
	SRC=$1
	DST=$2
	echo "Copying rules from \"$1\" to \"$2\""
fi

echo "Searching and copying \"yml\" files..."
find $SRC -name \*.yml -exec cp {} $DST \;
