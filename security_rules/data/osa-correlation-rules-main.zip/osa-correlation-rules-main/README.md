# OSA Correlation Rules
- Create virtual environment: `python -m venv myvenv`
- Activate virtual environment: `myvenv\Scripts\activate`
- Install packges: `pip install -r requirements.txt`

- To export osa rule excel file into yaml: `python excel_to_yaml.py osa_rules_sample.xlsx`\
Note: You can replace _osa_rules_sample.xlsx_ with other osa rule excel file that you saved in this directory.

- To import yaml files back into excel: `python yaml_to_excel.py`\
The script looks for all the .yml files in the folder _osa_rules_ and put them into an excel file similar to `osa_rules_sample.xlsx`.\
Note: The generated excel file has a timestamp in its name.

- To count the mapped technique in tags field of all yaml file and generate a new json file for MITRE: `python mitre_mapping.py attack_navigator_template.json` \
Note: attack_navigator_template.json is a template to be filled and the generated json file has a timestamp in its name.
