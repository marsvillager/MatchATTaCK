//README

The "rules_evaluation" branch is used to get some more insights on the currently available OSA rules.

