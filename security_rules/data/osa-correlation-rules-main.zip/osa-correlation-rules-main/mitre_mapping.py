import yaml
import glob
import json
import datetime
import sys

file_name = str(sys.argv[1])
yml_files = glob.glob("osa_rules/*.yml")
rule_columns = ["component", "name", "eventId", "eventType", "ciaLevel", "remarks", "script", "nameCN", "remarkCN",
                "ruleType", "redisEventKey", "parseEsResultKeys", "threshold", "timeWindow", "status", "source",
                "impact", "tags", "category", "keys"]
score_dict = {}
mitre_technique_list = []

for file in yml_files:
    with open(file, 'r', encoding='utf-8') as stream:
        try:
            rule_instance = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
            exit(0)
    tags = rule_instance["tags"].split(',')
    for item in tags:
        item = item.strip()
        if item.startswith('attack.ics.'):
            if item[11:] not in score_dict:
                score_dict[item[11:]] = 1
            else:
                score_dict[item[11:]] = score_dict[item[11:]] + 1

for item in score_dict:
    mitre_technique_list.append({'techniqueID':item,'score':score_dict[item]})

with open(file_name, mode='r', encoding='utf-8') as json_input:
    mitre_json = json.load(json_input)
    mitre_json['techniques'] = mitre_technique_list
filename = 'attack_navigator'+str(datetime.datetime.now()).replace(':', '-').replace(' ', '-')+'.json'
json.dump( mitre_json, open(filename, "w"), indent=4, sort_keys=True)
