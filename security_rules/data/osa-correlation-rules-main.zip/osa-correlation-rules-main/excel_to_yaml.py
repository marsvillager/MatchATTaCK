import pandas as pd
import yaml
import os
import re
import sys

osa_excel = str(sys.argv[1])

# read excel into dictionary
df_rule = pd.read_excel(osa_excel, index_col=None, header=None)
recs = df_rule.to_dict(orient='index')
rule_instance = {}
folder_name = 'osa_rules'

# make new directory if none exists
if not os.path.exists(folder_name):
    os.mkdir(folder_name)
for i in range(1, len(recs)):
    for j in range(len(recs[0])):
        rule_instance[recs[0][j]] = str(recs[i][j]) if str(recs[i][j]) != 'nan' else ''
        # column 'threshold', 'timeWindow' and 'status' should be integer instead of string
        if recs[0][j] in ['threshold', 'timeWindow', 'status']: rule_instance[recs[0][j]] = int(rule_instance[recs[0][j]])
    rule_name = re.sub("[^0-9a-zA-Z()]+", "_", rule_instance['name'])
    rule_filename = str(rule_instance['eventId']).zfill(5) + '_' + rule_name + '.yml'
    with open(folder_name + '/' + rule_filename, 'w', encoding='utf-8') as file:
        yaml.dump(rule_instance, file, default_flow_style=False, allow_unicode=True)
